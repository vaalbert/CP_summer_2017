/**
 * Created by prubac on 4/5/2017.
 */
public class InputProgramArgs {

    public static void main(String[] args) {
        for (String s : args) {
            System.out.println("Got: " + s);
        }
    }
}
