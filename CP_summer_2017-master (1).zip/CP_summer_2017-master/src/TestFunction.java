
/**
 * Created by prubac on 3/22/2017.
 */
public class TestFunction {

    public static void main(String[] args) {
        int s = BowlsRecursion.countBowls(6);

        // System.out.println(BowlsRecursion.v1);
    }
}
