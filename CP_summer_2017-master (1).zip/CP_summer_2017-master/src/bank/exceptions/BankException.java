package bank.exceptions;

/**
 * Created by prubac on 5/10/2017.
 */
public class BankException extends Exception {

    public BankException(String s) {
        super(s);
    }
}
