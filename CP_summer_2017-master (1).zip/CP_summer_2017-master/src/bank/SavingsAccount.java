package bank;

/**
 * Created by prubac on 4/19/2017.
 */
public class SavingsAccount extends Account {

    public SavingsAccount(Long accountId, Customer customer, String currency) {
        super(accountId, customer, currency);
    }
}
