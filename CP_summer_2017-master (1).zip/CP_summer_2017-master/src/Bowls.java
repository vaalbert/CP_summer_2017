/**
 * Created by prubac on 3/15/2017.
 */
public class Bowls {

    public static void main(String[] args) {

        int sum = 0;
        int n = 6;

        for (int i = 0; i <= n; i++) {
            sum = sum + i;
            //sum += i;
        }
        System.out.println(sum);
    }
}
