package shapes;

/**
 * Created by prubac on 4/12/2017.
 */
public interface PerimeterCalculation {
    double calculatePerimeter();
}
